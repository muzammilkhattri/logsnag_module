
# Unofficial Logsnag Prestashop Module 

A simple module to connect Logsnag with prestashop. Currently it only has one event, Notify when new order is placed on site.


## Screenshots

![App Screenshot](https://raw.githubusercontent.com/muzammilkhattri/logsnag_module/main/image.png)

